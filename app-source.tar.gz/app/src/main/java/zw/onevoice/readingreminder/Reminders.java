package zw.onevoice.readingreminder;

import android.app.AlarmManager;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Build;

/**
 * Schedules and shows reading reminders.
 *
 * The screen sends the full list of upcoming reminders (up to 31 Dec 2026), one per line:
 *   timeMillis \t notificationId \t title \t text
 * Each line becomes one alarm. The list is saved so alarms can be restored after a reboot.
 */
public class Reminders extends BroadcastReceiver {

    static final String CHANNEL = "readings";
    static final String ACTION_SHOW = "zw.onevoice.readingreminder.SHOW";
    static final String PREFS = "reminders";

    @Override
    public void onReceive(Context c, Intent i) {
        if (ACTION_SHOW.equals(i.getAction())) {
            show(c, i.getStringExtra("title"), i.getStringExtra("text"), i.getIntExtra("id", 1));
        } else {
            // Boot, app update, or clock/time-zone change: put the alarms back.
            schedule(c, prefs(c).getString("schedule", ""));
        }
    }

    /** Called from the screen. */
    static void handle(Context c, String command, String data) {
        if ("open".equals(command)) {
            // "Open NKJV": hands the link to the Bible app (YouVersion) if installed, otherwise the browser
            if (data != null && data.startsWith("https://")) {
                try {
                    c.startActivity(new Intent(Intent.ACTION_VIEW, android.net.Uri.parse(data))
                            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));
                } catch (android.content.ActivityNotFoundException ignored) { }
            }
        } else if ("test".equals(command)) {
            show(c, "Test reminder", data, 9999);
        } else if ("save".equals(command)) {
            prefs(c).edit().putString("schedule", data == null ? "" : data).apply();
            schedule(c, data);
        }
    }

    static SharedPreferences prefs(Context c) {
        return c.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }

    static int piFlags(int base) {
        return Build.VERSION.SDK_INT >= 23 ? base | PendingIntent.FLAG_IMMUTABLE : base;
    }

    static Intent showIntent(Context c) {
        return new Intent(c, Reminders.class).setAction(ACTION_SHOW);
    }

    static void schedule(Context c, String data) {
        AlarmManager am = (AlarmManager) c.getSystemService(Context.ALARM_SERVICE);
        if (am == null) return;

        // Cancel what was set last time.
        int previous = prefs(c).getInt("count", 0);
        for (int k = 0; k < previous; k++) {
            PendingIntent old = PendingIntent.getBroadcast(c, k, showIntent(c),
                    piFlags(PendingIntent.FLAG_NO_CREATE));
            if (old != null) { am.cancel(old); old.cancel(); }
        }

        long now = System.currentTimeMillis();
        int count = 0;
        if (data != null && !data.isEmpty()) {
            for (String line : data.split("\n")) {
                String[] f = line.split("\t");
                if (f.length != 4) continue;
                long when;
                int id;
                try { when = Long.parseLong(f[0]); id = Integer.parseInt(f[1]); }
                catch (NumberFormatException e) { continue; }
                if (when <= now) continue;

                Intent it = showIntent(c).putExtra("id", id).putExtra("title", f[2]).putExtra("text", f[3]);
                PendingIntent pi = PendingIntent.getBroadcast(c, count, it,
                        piFlags(PendingIntent.FLAG_UPDATE_CURRENT));
                setAlarm(am, when, pi);
                count++;
                if (count >= 450) break;   // Android allows ~500 alarms per app
            }
        }
        prefs(c).edit().putInt("count", count).apply();
    }

    static void setAlarm(AlarmManager am, long when, PendingIntent pi) {
        if (Build.VERSION.SDK_INT >= 31 && !am.canScheduleExactAlarms()) {
            am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, when, pi);   // may be a few minutes late
        } else if (Build.VERSION.SDK_INT >= 23) {
            am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, when, pi);
        } else {
            am.setExact(AlarmManager.RTC_WAKEUP, when, pi);
        }
    }

    static void createChannel(Context c) {
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationManager nm = c.getSystemService(NotificationManager.class);
            NotificationChannel ch = new NotificationChannel(CHANNEL, "Reading reminders",
                    NotificationManager.IMPORTANCE_HIGH);
            ch.setDescription("Daily Bible chapter and Desire of Ages reminders");
            nm.createNotificationChannel(ch);
        }
    }

    @SuppressWarnings("deprecation")
    static void show(Context c, String title, String text, int id) {
        createChannel(c);
        Notification.Builder b = Build.VERSION.SDK_INT >= 26
                ? new Notification.Builder(c, CHANNEL)
                : new Notification.Builder(c).setPriority(Notification.PRIORITY_HIGH)
                                             .setDefaults(Notification.DEFAULT_ALL);

        Intent open = new Intent(c, MainActivity.class).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        PendingIntent tap = PendingIntent.getActivity(c, 0, open, piFlags(PendingIntent.FLAG_UPDATE_CURRENT));

        b.setSmallIcon(R.drawable.ic_notify)
         .setColor(0xFF1F3A68)
         .setContentTitle(title)
         .setContentText(text)
         .setStyle(new Notification.BigTextStyle().bigText(text))
         .setAutoCancel(true)
         .setContentIntent(tap);

        NotificationManager nm = (NotificationManager) c.getSystemService(Context.NOTIFICATION_SERVICE);
        if (nm != null) nm.notify(id, b.build());
    }
}
